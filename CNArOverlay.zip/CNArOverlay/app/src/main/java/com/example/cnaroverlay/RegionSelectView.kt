package com.example.cnaroverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/**
 * شفافة بالكامل، تسمح للمستخدم بسحب مستطيل لتحديد منطقة على الشاشة
 * (مثلاً منطقة الحوار في اللعبة) بدلاً من فحص الشاشة كاملة.
 */
class RegionSelectView(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    private var startX = 0f
    private var startY = 0f
    private var endX = 0f
    private var endY = 0f
    private var dragging = false

    var onRegionSelected: ((Rect) -> Unit)? = null

    private val boxPaint = Paint().apply {
        color = Color.parseColor("#33FFFFFF")
        style = Paint.Style.FILL
    }

    private val borderPaint = Paint().apply {
        color = Color.RED
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startX = event.x
                startY = event.y
                endX = event.x
                endY = event.y
                dragging = true
            }
            MotionEvent.ACTION_MOVE -> {
                endX = event.x
                endY = event.y
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                dragging = false
                val rect = Rect(
                    minOf(startX, endX).toInt(),
                    minOf(startY, endY).toInt(),
                    maxOf(startX, endX).toInt(),
                    maxOf(startY, endY).toInt()
                )
                onRegionSelected?.invoke(rect)
            }
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (dragging || (endX != startX && endY != startY)) {
            canvas.drawRect(
                minOf(startX, endX), minOf(startY, endY),
                maxOf(startX, endX), maxOf(startY, endY),
                boxPaint
            )
            canvas.drawRect(
                minOf(startX, endX), minOf(startY, endY),
                maxOf(startX, endX), maxOf(startY, endY),
                borderPaint
            )
        }
    }
}
