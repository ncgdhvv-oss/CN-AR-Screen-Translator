package com.example.cnaroverlay

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var txtStatus: TextView

    private val screenCaptureLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                // نبدأ خدمة الالتقاط ونمرر لها نتيجة إذن MediaProjection
                val serviceIntent = Intent(this, CaptureService::class.java).apply {
                    action = CaptureService.ACTION_START
                    putExtra(CaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(CaptureService.EXTRA_RESULT_DATA, result.data)
                }
                ContextCompat.startForegroundService(this, serviceIntent)
                txtStatus.text = "الحالة: يعمل"
                Toast.makeText(this, "تم تشغيل المترجم", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "تم رفض صلاحية التقاط الشاشة", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("cnar_prefs", MODE_PRIVATE)
        txtStatus = findViewById(R.id.txtStatus)

        if (CaptureService.isRunning) {
            txtStatus.text = "الحالة: يعمل"
        }

        findViewById<Button>(R.id.btnGrantOverlay).setOnClickListener {
            requestOverlayPermission()
        }

        findViewById<Button>(R.id.btnPickRegion).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "امنح صلاحية العرض فوق التطبيقات أولاً", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(Intent(this, RegionPickerActivity::class.java))
            }
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            startTranslator()
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, CaptureService::class.java))
            stopService(Intent(this, OverlayService::class.java))
            txtStatus.text = "الحالة: متوقف"
        }
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        } else {
            Toast.makeText(this, "الصلاحية ممنوحة بالفعل", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startTranslator() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "يجب منح صلاحية العرض فوق التطبيقات أولاً (الخطوة 1)", Toast.LENGTH_LONG).show()
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                    100
                )
            }
        }

        // يبدأ خدمة الـ Overlay أولاً حتى تكون النافذة العائمة جاهزة لاستقبال النصوص
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))

        // ثم نطلب صلاحية التقاط الشاشة (MediaProjection) - نافذة نظام قياسية من أندرويد
        val projectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }
}
