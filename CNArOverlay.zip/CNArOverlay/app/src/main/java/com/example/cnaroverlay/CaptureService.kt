package com.example.cnaroverlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.security.MessageDigest

class CaptureService : Service() {

    companion object {
        const val ACTION_START = "com.example.cnaroverlay.START"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val CHANNEL_ID = "cnar_capture_channel"
        const val NOTIF_ID = 1001

        // كل كم مللي ثانية نفحص الشاشة (يمكن تعديلها حسب قوة الجهاز)
        const val SCAN_INTERVAL_MS = 1500L

        @Volatile
        var isRunning: Boolean = false
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0

    private val handler = Handler(Looper.getMainLooper())
    private val serviceScope = CoroutineScope(Dispatchers.Default + Job())

    private var lastTextHash: String = ""

    private val recognizer by lazy {
        TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    }

    private val scanRunnable = object : Runnable {
        override fun run() {
            captureAndProcess()
            handler.postDelayed(this, SCAN_INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundWithNotification()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START) {
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
            val data = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
            if (resultCode != -1 && data != null) {
                setupMediaProjection(resultCode, data)
            }
        }
        return START_STICKY
    }

    private fun startForegroundWithNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "التقاط الشاشة والترجمة",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("مترجم الشاشة يعمل")
            .setContentText("جاري فحص الشاشة بحثًا عن نصوص صينية...")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()

        startForeground(NOTIF_ID, notification)
    }

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        val projectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)

        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopCapture()
            }
        }, handler)

        val metrics = DisplayMetrics()
        val windowManager = getSystemService(WINDOW_SERVICE) as android.view.WindowManager
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)

        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi

        imageReader = ImageReader.newInstance(
            screenWidth, screenHeight, PixelFormat.RGBA_8888, 2
        )

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "CNArOverlayCapture",
            screenWidth, screenHeight, screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, handler
        )

        isRunning = true
        handler.postDelayed(scanRunnable, SCAN_INTERVAL_MS)
    }

    private fun captureAndProcess() {
        val reader = imageReader ?: return
        var image: Image? = null
        try {
            image = reader.acquireLatestImage()
        } catch (_: Exception) {
        }
        if (image == null) return

        val bitmap = imageToBitmap(image)
        image.close()
        if (bitmap == null) return

        val finalBitmap = applyRegionCropIfEnabled(bitmap)

        val inputImage = InputImage.fromBitmap(finalBitmap, 0)
        recognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                val chineseText = visionText.text.trim()
                if (chineseText.isEmpty()) return@addOnSuccessListener

                val hash = sha1(chineseText)
                if (hash == lastTextHash) {
                    // نفس النص السابق تمامًا - لا داعي لإعادة الترجمة
                    return@addOnSuccessListener
                }
                lastTextHash = hash

                serviceScope.launch(Dispatchers.IO) {
                    val arabic = Translator.translate(chineseText)
                    sendToOverlay(arabic)
                }
            }
    }

    /** يقتصّ الصورة على المنطقة التي حددها المستخدم إن كانت مفعّلة، وإلا يعيد الصورة كاملة */
    private fun applyRegionCropIfEnabled(bitmap: Bitmap): Bitmap {
        val prefs = getSharedPreferences("cnar_prefs", MODE_PRIVATE)
        val enabled = prefs.getBoolean("region_enabled", false)
        if (!enabled) return bitmap

        val left = prefs.getInt("region_left", 0).coerceIn(0, bitmap.width - 1)
        val top = prefs.getInt("region_top", 0).coerceIn(0, bitmap.height - 1)
        val right = prefs.getInt("region_right", bitmap.width).coerceIn(left + 1, bitmap.width)
        val bottom = prefs.getInt("region_bottom", bitmap.height).coerceIn(top + 1, bitmap.height)

        return try {
            Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
        } catch (_: Exception) {
            bitmap
        }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        return try {
            val planes = image.planes
            val buffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * screenWidth

            val bitmap = Bitmap.createBitmap(
                screenWidth + rowPadding / pixelStride,
                screenHeight,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)
            Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight)
        } catch (e: Exception) {
            null
        }
    }

    private fun sendToOverlay(arabicText: String) {
        val intent = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_UPDATE_TEXT
            putExtra(OverlayService.EXTRA_TEXT, arabicText)
        }
        startService(intent)
    }

    private fun sha1(text: String): String {
        val digest = MessageDigest.getInstance("SHA-1")
        val bytes = digest.digest(text.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun stopCapture() {
        handler.removeCallbacks(scanRunnable)
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        isRunning = false
    }

    override fun onDestroy() {
        super.onDestroy()
        stopCapture()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
