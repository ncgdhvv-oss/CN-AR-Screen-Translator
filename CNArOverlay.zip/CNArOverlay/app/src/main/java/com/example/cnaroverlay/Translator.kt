package com.example.cnaroverlay

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URLEncoder
import java.util.Collections
import java.util.LinkedHashMap

/**
 * ترجمة صيني -> عربي مع كاش بسيط (LRU) لتقليل استهلاك الإنترنت
 * وتجنّب إعادة ترجمة نفس النص المكرر.
 *
 * يستخدم نقطة نهاية ترجمة جوجل غير الرسمية (مجانية، بدون مفتاح API).
 * يمكن استبدالها لاحقًا بأي خدمة ترجمة رسمية إن رغبت (مثل LibreTranslate
 * أو Google Cloud Translation API مع مفتاح مدفوع).
 */
object Translator {

    private const val MAX_CACHE_SIZE = 500

    private val cache: LinkedHashMap<String, String> =
        object : LinkedHashMap<String, String>(16, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean {
                return size > MAX_CACHE_SIZE
            }
        }

    private val syncCache = Collections.synchronizedMap(cache)

    private val client = OkHttpClient()

    /**
     * ترجم نص صيني إلى عربي. يعيد النص الأصلي في حال فشل الاتصال.
     * دالة متزامنة (blocking) - يجب استدعاؤها من خيط خلفية (Dispatchers.IO).
     */
    fun translate(chineseText: String): String {
        val trimmed = chineseText.trim()
        if (trimmed.isEmpty()) return ""

        syncCache[trimmed]?.let { return it }

        return try {
            val encoded = URLEncoder.encode(trimmed, "UTF-8")
            // sl=auto يتعرف تلقائيًا سواء كان الرمز صيني مبسط أو تقليدي
            val url =
                "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ar&dt=t&q=$encoded"

            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return trimmed
                val body = response.body?.string() ?: return trimmed
                val root = JSONArray(body)
                val segments = root.getJSONArray(0)
                val sb = StringBuilder()
                for (i in 0 until segments.length()) {
                    val seg = segments.getJSONArray(i)
                    sb.append(seg.getString(0))
                }
                val result = sb.toString()
                if (result.isNotBlank()) {
                    syncCache[trimmed] = result
                    result
                } else {
                    trimmed
                }
            }
        } catch (e: Exception) {
            trimmed
        }
    }
}
