package com.example.cnaroverlay

import android.os.Bundle
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RegionPickerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        val hint = TextView(this).apply {
            text = "اسحب إصبعك لتحديد منطقة النص، ثم ارفع إصبعك للحفظ التلقائي"
            setBackgroundColor(0xAA000000.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(24, 24, 24, 24)
        }
        val selectView = RegionSelectView(this)

        root.addView(selectView)
        root.addView(hint)
        setContentView(root)

        selectView.onRegionSelected = { rect ->
            if (rect.width() > 20 && rect.height() > 20) {
                val prefs = getSharedPreferences("cnar_prefs", MODE_PRIVATE)
                prefs.edit()
                    .putInt("region_left", rect.left)
                    .putInt("region_top", rect.top)
                    .putInt("region_right", rect.right)
                    .putInt("region_bottom", rect.bottom)
                    .putBoolean("region_enabled", true)
                    .apply()
                Toast.makeText(this, "تم حفظ المنطقة المحددة", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "المنطقة صغيرة جدًا، حاول مرة أخرى", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
